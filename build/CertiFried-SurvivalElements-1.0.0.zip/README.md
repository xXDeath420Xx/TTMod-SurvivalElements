# SurvivalElements

Adds survival mechanics and maintenance tools to Techtonica.

## Features

### Equipment
- **Repair Tool** - Repair damaged machines and restore them to working order

## Requirements
- BepInEx 5.4.21+
- EquinoxsModUtils 6.1.3+
- EMUAdditions 2.0.0+
- TechtonicaFramework 1.0.0+

## Installation
Install via r2modman or manually place the DLL in your BepInEx/plugins folder.

## Credits
Created by CertiFried
