# Changelog

All notable changes to SurvivalElements will be documented in this file.

## [2.6.1] - 2026-01-07

### Changed
- All items now appear in unified "Modded" build menu tab
- Updated dependency on TechtonicaFramework 1.2.0

### Fixed
- Build menu organization for cleaner UI

## [1.0.0] - 2025-01-05

### Added
- Initial release
- **Repair Tool** - Equipment for repairing damaged machines
- Machine health and repair mechanics integration
- Tech tree unlock for Repair Tool
