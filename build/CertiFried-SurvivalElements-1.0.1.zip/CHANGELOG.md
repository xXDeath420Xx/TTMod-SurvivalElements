# Changelog

All notable changes to SurvivalElements will be documented in this file.

## [1.0.0] - 2025-01-05

### Added
- Initial release
- **Repair Tool** - Equipment for repairing damaged machines
- Machine health and repair mechanics integration
- Tech tree unlock for Repair Tool
